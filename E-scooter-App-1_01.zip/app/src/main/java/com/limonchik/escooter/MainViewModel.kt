package com.limonchik.escooter

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** BASIC — фонари, блокировка, выключение. ADVANCED — передачи, скорости, режимы (нужен переключатель в настройках). */
enum class Level { BASIC, ADVANCED, DANGEROUS }

data class UiState(
    val mode: ThemeMode = ThemeMode.SYSTEM,
    val style: DesignStyle = DesignStyle.APPLE,
    val advanced: Boolean = false,
    val scanning: Boolean = false,
    val found: List<Found> = emptyList(),
    val conn: ConnState = ConnState.DISCONNECTED,
    val connAddress: String? = null,
    val lastAddress: String? = null,
    val status: Protocol.Status? = null,
    val ped: Protocol.Ped? = null,
    val bounds: Protocol.Bounds? = null,
    val info: Map<String, String> = emptyMap(),
    val log: List<String> = emptyList(),
    val speedHistory: List<Float> = emptyList(),
    val sessionMax: Float = 0f,
    val message: String? = null,
    val messageId: Long = 0L,
)

class MainViewModel(app: Application) : AndroidViewModel(app), BleClient.Listener {

    private val prefs = app.getSharedPreferences("escooter", Context.MODE_PRIVATE)
    private val _ui = MutableStateFlow(
        UiState(
            mode = loadEnum("mode", ThemeMode.SYSTEM),
            style = loadEnum("style", DesignStyle.APPLE),
            lastAddress = prefs.getString("last", null),
        ),
    )
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val ble = BleClient(app, this)
    private val lines = ArrayDeque<String>()
    private val lastRx = HashMap<Int, ByteArray>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private inline fun <reified T : Enum<T>> loadEnum(key: String, def: T): T =
        try { enumValueOf<T>(prefs.getString(key, def.name) ?: def.name) } catch (e: Exception) { def }

    fun setMode(m: ThemeMode) {
        prefs.edit().putString("mode", m.name).apply()
        _ui.update { it.copy(mode = m) }
    }

    fun setStyle(s: DesignStyle) {
        prefs.edit().putString("style", s.name).apply()
        _ui.update { it.copy(style = s) }
    }

    /** Не сохраняется: после перезапуска расширенное управление снова выключено. */
    fun setAdvanced(on: Boolean) {
        _ui.update { it.copy(advanced = on) }
        log("INFO", "Расширенное управление: $on")
    }

    fun say(text: String) {
        _ui.update { it.copy(message = text, messageId = it.messageId + 1) }
        log("INFO", text)
    }

    private fun log(dir: String, text: String) {
        lines.addLast("${fmt.format(Date())} $dir $text")
        while (lines.size > 500) lines.removeFirst()
        _ui.update { it.copy(log = lines.toList()) }
    }

    fun clearLog() {
        lines.clear()
        lastRx.clear()
        _ui.update { it.copy(log = emptyList()) }
    }

    fun export(uri: Uri) {
        val st = _ui.value
        val head = buildString {
            appendLine("${Config.APP_NAME} ${Config.VERSION} — журнал пакетов")
            appendLine("Время: ${Date()}")
            appendLine("ALLOW_WRITE=${Config.ALLOW_WRITE} ADVANCED=${st.advanced}")
            appendLine("Устройство: ${st.connAddress ?: "-"}")
            st.info.forEach { (k, v) -> appendLine("$k: $v") }
            appendLine("----")
        }
        val body = lines.joinToString("\n")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use {
                    it.write((head + body + "\n").toByteArray(Charsets.UTF_8))
                }
                say("Журнал сохранён")
            } catch (e: Exception) {
                say("Экспорт не удался: ${e.message}")
            }
        }
    }

    // ---------- подключение ----------
    fun startScan() = ble.startScan()
    fun stopScan() = ble.stopScan()
    fun connect(addr: String) = ble.connect(addr)
    fun disconnect() = ble.disconnect()
    fun connectLast() {
        val a = _ui.value.lastAddress
        if (a == null) say("Нет сохранённого самоката") else ble.connect(a)
    }
    fun refreshInfo() = ble.readAllInfo()

    // ---------- отправка ----------
    private fun snap(): Protocol.Snap? {
        val st = _ui.value.status ?: return null
        val ped = _ui.value.ped
        return Protocol.Snap(st.setting, st.thirdGearView, ped?.view ?: false, ped?.bit2 ?: false)
    }

    private fun send(label: String, frames: List<ByteArray>, level: Level) {
        val allowed = when (level) {
            Level.BASIC -> Config.ALLOW_WRITE
            Level.ADVANCED -> Config.ALLOW_WRITE && Config.ALLOW_SPEED_MODES && _ui.value.advanced
            Level.DANGEROUS -> Config.ALLOW_WRITE && Config.ALLOW_DANGEROUS
        }
        frames.forEach { log(if (allowed) "TX  " else "TX-DRY", Protocol.hex(it) + "  [$label]") }
        if (!allowed) {
            say(
                when (level) {
                    Level.BASIC -> "Запись выключена в Config.kt"
                    Level.ADVANCED -> "Включите «Расширенное управление» в настройках"
                    Level.DANGEROUS -> "Эта функция отключена в сборке"
                },
            )
            return
        }
        if (_ui.value.conn != ConnState.READY) {
            say("Нет подключения к самокату")
            return
        }
        ble.write(frames)
        say("Отправлено: $label")
    }

    private fun cmd(label: String, level: Level, build: (Protocol.Snap) -> ByteArray) {
        val s = snap()
        if (s == null) {
            say("Нет данных от контроллера")
            return
        }
        send(label, listOf(build(s)), level)
    }

    private fun onOff(on: Boolean) = if (on) "вкл" else "выкл"

    fun setHeadlight(on: Boolean) = cmd("Передний фонарь ${onOff(on)}", Level.BASIC) { Protocol.bitCommand(it, Protocol.W_HEAD, on) }
    fun setTaillight(on: Boolean) = cmd("Задний фонарь ${onOff(on)}", Level.BASIC) { Protocol.bitCommand(it, Protocol.W_TAIL, on) }

    fun setLock(on: Boolean) {
        val sp = _ui.value.status?.speedRaw ?: 0
        if (on && sp > 0) {
            say("Блокировка только на стоящем самокате")
            return
        }
        cmd("Блокировка колеса ${onOff(on)}", Level.BASIC) { Protocol.bitCommand(it, Protocol.W_LOCK, on) }
    }

    fun shutdown() = cmd("Выключение самоката", Level.BASIC) { Protocol.shutdown(it) }
    fun factoryReset() = cmd("Сброс настроек контроллера", Level.DANGEROUS) { Protocol.restore(it) }

    fun setBit(bit: Int, on: Boolean, name: String) =
        cmd("$name ${onOff(on)}", Level.ADVANCED) { Protocol.bitCommand(it, bit, on) }

    fun setPedestrian(on: Boolean) = cmd("Пешеходный режим ${onOff(on)}", Level.ADVANCED) { Protocol.pedestrian(it, on) }

    fun setGear(g: Int) = when (g) {
        1 -> cmd("Передача 1", Level.ADVANCED) { Protocol.gear1(it) }
        2 -> cmd("Передача 2", Level.ADVANCED) { Protocol.gear2(it) }
        else -> cmd("Передача 3", Level.ADVANCED) { Protocol.gear3(it) }
    }

    /** Скорость передачи в км/ч: с ограничением 50 и пределами контроллера из AA 57. */
    fun setGearSpeed(gear: Int, kmh: Int) {
        val ped = _ui.value.ped
        val b = _ui.value.bounds
        if (ped == null || ped.one == 0 || ped.two == 0 || ped.three == 0) {
            say("Нет данных о скоростях от контроллера")
            return
        }
        if (_ui.value.status?.cycling == true) {
            say("Скорость не меняется во время езды")
            return
        }
        var v = kmh.coerceIn(1, Config.MAX_SPEED_KMH)
        if (b != null) {
            val r = b.range(gear)
            if (r.second > 0) v = v.coerceIn(r.first, r.second.coerceAtMost(Config.MAX_SPEED_KMH))
        }
        val frame = when (gear) {
            1 -> Protocol.speed12(v, ped.two)
            2 -> Protocol.speed12(ped.one, v)
            else -> Protocol.speed3(v, ped.start, ped.three)
        }
        send("Скорость передачи $gear: $v км/ч", List(Config.SPEED_FRAME_REPEAT) { frame }, Level.ADVANCED)
    }

    /** Профиль из трёх скоростей: пределы 50 км/ч и диапазон контроллера (AA 57) учитываются для каждой передачи. */
    fun applySpeedProfile(profile: SpeedProfile) {
        val ped = _ui.value.ped
        val b = _ui.value.bounds
        if (ped == null || ped.one == 0 || ped.two == 0 || ped.three == 0) {
            say("Нет данных о скоростях от контроллера")
            return
        }
        if (_ui.value.status?.cycling == true) {
            say("Скорость не меняется во время езды")
            return
        }
        fun limit(gear: Int, kmh: Int): Int {
            var v = kmh.coerceIn(1, Config.MAX_SPEED_KMH)
            if (b != null) {
                val r = b.range(gear)
                if (r.second > 0) {
                    val hi = minOf(r.second, Config.MAX_SPEED_KMH)
                    val lo = minOf(r.first, hi)
                    v = v.coerceIn(lo, hi)
                }
            }
            return v
        }
        val v1 = limit(1, profile.g1)
        val v2 = limit(2, profile.g2)
        val v3 = limit(3, profile.g3)
        val f12 = Protocol.speed12(v1, v2)
        val f3 = Protocol.speed3(v3, ped.start, ped.three)
        val frames = List(Config.SPEED_FRAME_REPEAT) { f12 } + List(Config.SPEED_FRAME_REPEAT) { f3 }
        send("Профиль ${profile.name}: $v1/$v2/$v3 км/ч", frames, Level.ADVANCED)
    }

    // ---------- BleClient.Listener ----------
    override fun onScan(list: List<Found>) = _ui.update { it.copy(found = list) }
    override fun onScanning(on: Boolean) = _ui.update { it.copy(scanning = on) }

    override fun onConn(s: ConnState, address: String?) {
        if (s == ConnState.READY && address != null) prefs.edit().putString("last", address).apply()
        _ui.update {
            if (s == ConnState.DISCONNECTED) {
                it.copy(conn = s, connAddress = null, status = null, ped = null, bounds = null)
            } else {
                it.copy(conn = s, connAddress = address ?: it.connAddress, lastAddress = if (s == ConnState.READY && address != null) address else it.lastAddress)
            }
        }
        log("CONN", "$s ${address ?: ""}")
    }

    override fun onRx(data: ByteArray) {
        val type = if (data.size >= 2) data[1].toInt() and 0xFF else -1
        val prev = lastRx[type]
        if (prev == null || !prev.contentEquals(data)) {
            lastRx[type] = data.copyOf()
            log("RX  ", Protocol.hex(data))
        }
        when (type) {
            0x55 -> Protocol.parseStatus(data)?.let { st ->
                val sp = st.speedKmh.toFloat()
                _ui.update {
                    val hist = (it.speedHistory + sp).takeLast(90)
                    it.copy(status = st, speedHistory = hist, sessionMax = maxOf(it.sessionMax, sp))
                }
            }
            0x56 -> Protocol.parsePed(data)?.let { p -> _ui.update { it.copy(ped = p) } }
            0x57 -> Protocol.parseBounds(data)?.let { b -> _ui.update { it.copy(bounds = b) } }
        }
    }

    override fun onInfo(name: String, data: ByteArray) {
        val hex = Protocol.hex(data)
        val text = if (data.isNotEmpty() && data.all { it.toInt() in 32..126 }) String(data, Charsets.US_ASCII) else hex
        _ui.update { it.copy(info = it.info + (name to text)) }
        log("READ", "$name = $hex")
    }

    override fun onTx(data: ByteArray) = log("SENT", Protocol.hex(data) + "  (записано в FFF6)")
    override fun onNote(text: String) = log("NOTE", text)
}

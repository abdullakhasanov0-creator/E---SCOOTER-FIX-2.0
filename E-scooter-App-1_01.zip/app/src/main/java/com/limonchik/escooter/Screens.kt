package com.limonchik.escooter

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

enum class Tab(val title: String, val glyph: String) {
    HOME("Главная", "🛴"),
    SPEED("Скорость", "⚡"),
    DIAG("Диагностика", "🩺"),
    SETTINGS("Настройки", "⚙️"),
}

enum class Sub { CONNECT, FIRMWARE, ABOUT, LOG }

private const val KM_PER_MILE = 1.609344

private fun fmt1(v: Double): String = String.format(Locale.US, "%.1f", v)

private fun fmtTime(sec: Int): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "$h ч $m м $s с" else "$m м $s с"
}

private fun dist(raw: Int, miles: Boolean): String =
    if (miles) "${fmt1(raw / 10.0 / KM_PER_MILE)} mi" else "${fmt1(raw / 10.0)} км"

@Composable
fun AppRoot(vm: MainViewModel) {
    val ui by vm.ui.collectAsState()
    val p = LocalPalette.current
    var tab by remember { mutableStateOf(Tab.HOME) }
    var sub by remember { mutableStateOf<Sub?>(null) }
    var lastSub by remember { mutableStateOf(Sub.ABOUT) }
    var menu by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf("") }
    var toast by remember { mutableStateOf(false) }

    val perms = if (Build.VERSION.SDK_INT >= 31) {
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) vm.startScan() else vm.say("Нет разрешений Bluetooth")
    }
    val scan: () -> Unit = { permLauncher.launch(perms) }
    val open: (Sub) -> Unit = { lastSub = it; sub = it }
    val askAdvanced: () -> Unit = { confirm = "adv" }

    BackHandler(enabled = sub != null) { sub = null }
    LaunchedEffect(ui.messageId) {
        if (ui.messageId > 0L) {
            toast = true
            delay(2400)
            toast = false
        }
    }

    Box(Modifier.fillMaxSize().background(p.bg)) {
        Column(Modifier.fillMaxSize()) {
            TopBar(ui, menu, { menu = it }, open, { confirm = "off" }, vm)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedContent(
                    targetState = tab,
                    transitionSpec = {
                        (fadeIn(tween(170)) + slideInVertically(tween(170)) { it / 24 }) togetherWith fadeOut(tween(110))
                    },
                    label = "tabs",
                ) { t ->
                    when (t) {
                        Tab.HOME -> HomeScreen(vm, ui, open, scan, askAdvanced)
                        Tab.SPEED -> SpeedScreen(vm, ui, askAdvanced)
                        Tab.DIAG -> DiagScreen(ui)
                        Tab.SETTINGS -> SettingsScreen(vm, ui, open, askAdvanced)
                    }
                }
            }
            TabBar(tab) { tab = it }
        }

        AnimatedVisibility(
            visible = sub != null,
            enter = slideInHorizontally(tween(220)) { it } + fadeIn(tween(160)),
            exit = slideOutHorizontally(tween(180)) { it } + fadeOut(tween(120)),
        ) {
            Box(Modifier.fillMaxSize().background(p.bg)) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                    when (lastSub) {
                        Sub.CONNECT -> ConnectScreen(vm, ui, scan) { sub = null }
                        Sub.FIRMWARE -> FirmwareScreen(vm, ui, askAdvanced) { sub = null }
                        Sub.ABOUT -> AboutScreen { sub = null }
                        Sub.LOG -> LogScreen(vm, ui) { sub = null }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = toast,
            modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 6.dp),
            enter = fadeIn(tween(140)) + slideInVertically(tween(140)) { -it },
            exit = fadeOut(tween(140)),
        ) {
            Box(
                Modifier.padding(horizontal = 24.dp).clip(RoundedCornerShape(50)).background(p.text).padding(horizontal = 18.dp, vertical = 10.dp),
            ) { Text(ui.message ?: "", color = p.bg, fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center) }
        }
    }

    if (confirm == "off") {
        ConfirmDialog(
            title = "Выключить самокат?",
            text = "Отправится команда выключения. Включить самокат снова можно кнопкой на руле.",
            action = "Выключить",
            onYes = { vm.shutdown(); confirm = "" },
            onNo = { confirm = "" },
        )
    }
    if (confirm == "adv") {
        ConfirmDialog(
            title = "Расширенное управление",
            text = "Откроет смену передач, скоростей и режимов контроллера. Команды собраны из оригинального приложения, но на вашем самокате не проверены. Всё делаете на свой риск, в том числе соблюдение местных правил скорости.",
            action = "Включить",
            onYes = { vm.setAdvanced(true); confirm = "" },
            onNo = { confirm = "" },
        )
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, action: String, onYes: () -> Unit, onNo: () -> Unit) {
    val p = LocalPalette.current
    AlertDialog(
        onDismissRequest = onNo,
        containerColor = p.card,
        titleContentColor = p.text,
        textContentColor = p.sub,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onYes) { Text(action, color = p.accent) } },
        dismissButton = { TextButton(onClick = onNo) { Text("Отмена", color = p.sub) } },
    )
}

@Composable
fun TopBar(ui: UiState, menu: Boolean, setMenu: (Boolean) -> Unit, open: (Sub) -> Unit, onShutdown: () -> Unit, vm: MainViewModel) {
    val p = LocalPalette.current
    val dot = when (ui.conn) {
        ConnState.READY -> p.good
        ConnState.CONNECTING -> p.warn
        ConnState.DISCONNECTED -> p.sub
    }
    val label = when (ui.conn) {
        ConnState.READY -> "Подключено"
        ConnState.CONNECTING -> "Подключение…"
        ConnState.DISCONNECTED -> "Не подключено"
    }
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(Config.APP_NAME, color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Spacer(Modifier.width(6.dp))
                Text(label, color = p.sub, fontSize = 13.sp)
            }
        }
        Box {
            Pressable(onClick = { setMenu(true) }, modifier = Modifier.size(40.dp), shape = CircleShape, color = p.card) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Меню", tint = p.text)
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { setMenu(false) }) {
                DropdownMenuItem(text = { Text("Подключение") }, onClick = { setMenu(false); open(Sub.CONNECT) })
                DropdownMenuItem(text = { Text("Прошивки") }, onClick = { setMenu(false); open(Sub.FIRMWARE) })
                DropdownMenuItem(text = { Text("О приложении") }, onClick = { setMenu(false); open(Sub.ABOUT) })
                if (ui.conn != ConnState.DISCONNECTED) {
                    DropdownMenuItem(text = { Text("Отключиться") }, onClick = { setMenu(false); vm.disconnect() })
                }
                if (ui.conn == ConnState.READY) {
                    DropdownMenuItem(text = { Text("Выключить самокат", color = p.bad) }, onClick = { setMenu(false); onShutdown() })
                }
            }
        }
    }
}

@Composable
fun TabBar(selected: Tab, onSelect: (Tab) -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxWidth().background(p.card)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(p.divider))
        Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 6.dp)) {
            Tab.values().forEach { t ->
                val on = t == selected
                val scale by animateFloatAsState(if (on) 1.15f else 1f, tween(140), label = "tabScale")
                val color by animateColorAsState(if (on) p.accent else p.sub, tween(140), label = "tabColor")
                Pressable(
                    onClick = { onSelect(t) },
                    modifier = Modifier.weight(1f),
                    shape = RectangleShape,
                    color = Color.Transparent,
                ) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(t.glyph, fontSize = 22.sp, modifier = Modifier.graphicsLayer { scaleX = scale; scaleY = scale })
                        Text(t.title, color = color, fontSize = 11.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}

@Composable
fun SubHeader(title: String, onBack: () -> Unit) {
    val p = LocalPalette.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Pressable(onClick = onBack, modifier = Modifier.size(40.dp), shape = CircleShape, color = p.card) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("‹", color = p.accent, fontSize = 30.sp) }
        }
        Spacer(Modifier.width(12.dp))
        Text(title, color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Stat(value: String, label: String) {
    val p = LocalPalette.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = p.sub, fontSize = 12.sp)
    }
}

@Composable
fun HomeScreen(vm: MainViewModel, ui: UiState, open: (Sub) -> Unit, scan: () -> Unit, askAdvanced: () -> Unit) {
    val p = LocalPalette.current
    val st = ui.status
    val s = st?.setting
    val connected = ui.conn == ConnState.READY
    val miles = s?.unitMiles == true
    val speed = if (st == null) 0f else (if (miles) st.speedKmh / KM_PER_MILE else st.speedKmh).toFloat()
    val pedOn = ui.ped?.let { it.view && it.bit2 } == true

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
        Box(Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(p.radius))) {
            Image(
                painter = painterResource(R.drawable.scooter_hero),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alignment = Alignment.BottomCenter,
                modifier = Modifier.fillMaxSize(),
            )
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))
            Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                Text("Ninebot Max G30", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (connected) "Контроллер KCQ · на связи" else "Контроллер KCQ · нет связи",
                    color = Color(0xCCFFFFFF), fontSize = 13.sp,
                )
            }
            Pressable(
                onClick = { if (ui.conn == ConnState.DISCONNECTED) { open(Sub.CONNECT); scan() } else vm.disconnect() },
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
                shape = RoundedCornerShape(50),
                color = Color(0x99000000),
            ) {
                Text(
                    if (ui.conn == ConnState.DISCONNECTED) "Подключить" else "Отключить",
                    color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        CardBox {
            SpeedGauge(speed, if (miles) (Config.MAX_SPEED_KMH / KM_PER_MILE).toFloat() else Config.MAX_SPEED_KMH.toFloat(), if (miles) "mph" else "км/ч", Modifier.fillMaxWidth(0.72f).align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat(if (st == null) "—" else "${st.battery}%", "Заряд")
                Stat(if (st == null) "—" else dist(st.tripRaw, miles), "Поездка")
                Stat(if (st == null) "—" else dist(st.totalRaw, miles), "Всего")
            }
        }

        SectionTitle("Быстрое управление")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("💡", "Передний свет", if (s?.headlight == true) "Включён" else "Выключен", s?.headlight == true, Modifier.weight(1f), connected) {
                vm.setHeadlight(s?.headlight != true)
            }
            Tile("🔴", "Задний свет", if (s?.taillight == true) "Включён" else "Выключен", s?.taillight == true, Modifier.weight(1f), connected) {
                vm.setTaillight(s?.taillight != true)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile(if (s?.lock == true) "🔒" else "🔓", "Блокировка", if (s?.lock == true) "Колесо заблокировано" else "Разблокировано", s?.lock == true, Modifier.weight(1f), connected) {
                vm.setLock(s?.lock != true)
            }
            Tile("🚶", "Пешеходный", if (ui.ped?.view != true) "Нет данных" else if (pedOn) "Включён" else "Выключен", pedOn, Modifier.weight(1f), connected && ui.ped?.view == true) {
                vm.setPedestrian(!pedOn)
            }
        }

        SectionTitle("Передача")
        CardBox {
            Segmented(listOf("1", "2", "3"), ((s?.gear ?: 1) - 1).coerceIn(0, 2)) { vm.setGear(it + 1) }
            if (!ui.advanced) {
                Spacer(Modifier.height(10.dp))
                Text("Смена передач и режимов закрыта защитой.", color = p.sub, fontSize = 13.sp)
                TextButton(onClick = askAdvanced) { Text("Включить расширенное управление", color = p.accent) }
            }
        }
    }
}

@Composable
fun SpeedScreen(vm: MainViewModel, ui: UiState, askAdvanced: () -> Unit) {
    val p = LocalPalette.current
    val ped = ui.ped
    var pending by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
        BigTitle("Скорость")
        Text(
            "Максимум ${Config.MAX_SPEED_KMH} км/ч, дальше контроллер сам ограничивает диапазон.",
            color = p.sub, fontSize = 14.sp, modifier = Modifier.padding(start = 6.dp, top = 4.dp, bottom = 8.dp),
        )
        if (!ui.advanced) {
            CardBox {
                Text("Изменение скоростей закрыто", color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("Включите расширенное управление, чтобы менять скорость передач.", color = p.sub, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                SecondaryButton("Включить") { askAdvanced() }
            }
        }
        if (ped == null || ped.one == 0 || ped.two == 0 || ped.three == 0) {
            Spacer(Modifier.height(12.dp))
            CardBox { Text("Нет данных о скоростях. Подключите самокат и подождите пару секунд.", color = p.sub, fontSize = 15.sp) }
        } else {
            for (g in 1..3) {
                Spacer(Modifier.height(12.dp))
                val cur = when (g) { 1 -> ped.one; 2 -> ped.two; else -> ped.three }
                val r = ui.bounds?.range(g)
                val lo = r?.first ?: 1
                val hi = if (r != null && r.second > 0) r.second else Config.MAX_SPEED_KMH
                GearCard(g, cur, lo, hi) { v ->
                    if (v > 25) pending = g to v else vm.setGearSpeed(g, v)
                }
            }
            if (ped.start != 0) {
                Spacer(Modifier.height(12.dp))
                CardBox { InfoRow("Стартовая скорость", "${ped.start} км/ч") }
            }
        }
    }

    val pd = pending
    if (pd != null) {
        ConfirmDialog(
            title = "Скорость выше 25 км/ч",
            text = "Во многих странах выше 25 км/ч ездить на самокате по общим дорогам нельзя. Применить ${pd.second} км/ч для передачи ${pd.first}?",
            action = "Применить",
            onYes = { vm.setGearSpeed(pd.first, pd.second); pending = null },
            onNo = { pending = null },
        )
    }
}

@Composable
private fun GearCard(gear: Int, cur: Int, lo: Int, hi: Int, onApply: (Int) -> Unit) {
    val p = LocalPalette.current
    val top = hi.coerceIn(1, Config.MAX_SPEED_KMH)
    val bottom = lo.coerceIn(1, top)
    var v by remember(cur, top, bottom) { mutableFloatStateOf(cur.toFloat().coerceIn(bottom.toFloat(), top.toFloat())) }
    CardBox {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Передача $gear", color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text("${v.roundToInt()} км/ч", color = p.accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        if (top > bottom) {
            Slider(
                value = v,
                onValueChange = { v = it },
                valueRange = bottom.toFloat()..top.toFloat(),
                colors = SliderDefaults.colors(thumbColor = p.accent, activeTrackColor = p.accent, inactiveTrackColor = p.cardAlt),
            )
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("сейчас $cur", color = p.sub, fontSize = 13.sp)
            Text("допустимо $bottom–$top", color = p.sub, fontSize = 13.sp)
        }
        PrimaryButton("Применить", enabled = v.roundToInt() != cur) { onApply(v.roundToInt()) }
    }
}

@Composable
fun DiagScreen(ui: UiState) {
    val p = LocalPalette.current
    val st = ui.status
    val s = st?.setting
    val miles = s?.unitMiles == true
    fun onOff(b: Boolean) = if (b) "включён" else "выключен"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
        BigTitle("Диагностика")
        if (st == null) {
            Spacer(Modifier.height(12.dp))
            CardBox { Text("Нет данных от контроллера. Подключите самокат.", color = p.sub, fontSize = 15.sp) }
        } else {
            SectionTitle("Батарея")
            CardBox {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${st.battery}%", color = p.text, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text(if (st.battery <= 15) "Низкий заряд" else if (st.battery <= 35) "Средний заряд" else "Хороший заряд", color = p.sub, fontSize = 14.sp)
                }
                Spacer(Modifier.height(10.dp))
                BatteryBar(st.battery)
            }

            SectionTitle("Ошибки")
            CardBox {
                val faults = st.faults
                if (faults.isEmpty()) {
                    Text("✅ Ошибок нет", color = p.good, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                } else {
                    faults.forEachIndexed { i, f ->
                        if (i > 0) Spacer(Modifier.height(10.dp))
                        Text("⚠️ ${f.title}", color = p.bad, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text(f.hint, color = p.sub, fontSize = 13.sp)
                    }
                }
            }

            SectionTitle("Поездка")
            CardBox {
                InfoRow("Время в пути", fmtTime(st.rideSeconds))
                Divider1()
                InfoRow("Пробег за поездку", dist(st.tripRaw, miles))
                Divider1()
                InfoRow("Общий пробег", dist(st.totalRaw, miles))
                Divider1()
                val mx = if (miles) ui.sessionMax / KM_PER_MILE else ui.sessionMax.toDouble()
                InfoRow("Макс. скорость за сеанс", "${fmt1(mx)} ${if (miles) "mph" else "км/ч"}")
                Spacer(Modifier.height(10.dp))
                SpeedChart(ui.speedHistory)
            }

            SectionTitle("Состояние")
            CardBox {
                InfoRow("Передача", "${s?.gear ?: 1}")
                Divider1()
                InfoRow("Блокировка", if (s?.lock == true) "включена" else "выключена")
                Divider1()
                InfoRow("Передний свет", onOff(s?.headlight == true))
                Divider1()
                InfoRow("Задний свет", onOff(s?.taillight == true))
                Divider1()
                InfoRow("Круиз", onOff(s?.cruise == true))
                Divider1()
                InfoRow("Режим старта", onOff(s?.startMode == true))
                Divider1()
                InfoRow("Единицы", if (miles) "мили" else "километры")
                Divider1()
                InfoRow("В движении", if (st.cycling) "да" else "нет")
            }
        }

        SectionTitle("Версии и устройство")
        CardBox {
            InfoRow("Приложение", Config.VERSION)
            Divider1()
            InfoRow("Адрес", ui.connAddress ?: "—")
            if (ui.info.isEmpty()) {
                Divider1()
                Text("Контроллер не сообщает версии. Читаются стандартные характеристики 180A.", color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }
            ui.info.forEach { (k, v) ->
                Divider1()
                InfoRow(k, v)
            }
        }
    }
}

@Composable
private fun NavRow(glyph: String, title: String, subtitle: String, onClick: () -> Unit) {
    val p = LocalPalette.current
    Pressable(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(p.tileRadius), color = Color.Transparent) {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(p.cardAlt), contentAlignment = Alignment.Center) { Text(glyph, fontSize = 17.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text(subtitle, color = p.sub, fontSize = 13.sp)
            }
            Text("›", color = p.sub, fontSize = 24.sp)
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, ui: UiState, open: (Sub) -> Unit, askAdvanced: () -> Unit) {
    val p = LocalPalette.current
    val st = ui.status
    val s = st?.setting
    val ready = ui.conn == ConnState.READY && st != null
    val pedOn = ui.ped?.let { it.view && it.bit2 } == true

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
        BigTitle("Настройки")

        SectionTitle("Оформление")
        CardBox {
            Text("Стиль", color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            Segmented(listOf("Apple", "Ninebot"), ui.style.ordinal) { vm.setStyle(DesignStyle.values()[it]) }
            Spacer(Modifier.height(14.dp))
            Text("Тема", color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            Segmented(listOf("Системная", "Светлая", "Тёмная"), ui.mode.ordinal) { vm.setMode(ThemeMode.values()[it]) }
        }

        SectionTitle("Управление")
        CardBox {
            SwitchRow("Расширенное управление", "Передачи, скорости и режимы контроллера. После перезапуска выключается.", ui.advanced) {
                if (it) askAdvanced() else vm.setAdvanced(false)
            }
        }

        SectionTitle("Режимы контроллера")
        CardBox {
            SwitchRow("Круиз-контроль", "Удержание скорости", s?.cruise == true, ready) { vm.setBit(Protocol.W_CRUISE, it, "Круиз") }
            Divider1()
            SwitchRow("Режим старта", "Как в оригинальном приложении", s?.startMode == true, ready) { vm.setBit(Protocol.W_START, it, "Режим старта") }
            Divider1()
            SwitchRow("Мили вместо километров", "Только отображение", s?.unitMiles == true, ready) { vm.setBit(Protocol.W_UNIT, it, "Мили") }
            Divider1()
            SwitchRow("Пешеходный режим", if (ui.ped?.view == true) "Низкая скорость рядом с самокатом" else "Контроллер не сообщает поддержку", pedOn, ready && ui.ped?.view == true) { vm.setPedestrian(it) }
            if (!ui.advanced) {
                Text("Чтобы менять режимы, включите расширенное управление.", color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        SectionTitle("Прочее")
        CardBox {
            NavRow("🔌", "Подключение", "Поиск и выбор самоката") { open(Sub.CONNECT) }
            Divider1()
            NavRow("💾", "Прошивки", "Версии и профили скорости") { open(Sub.FIRMWARE) }
            Divider1()
            NavRow("ℹ️", "О приложении", "Версия ${Config.VERSION}") { open(Sub.ABOUT) }
        }

        SectionTitle("Для разработчиков")
        CardBox {
            NavRow("🧾", "Журнал пакетов", "Hex-кадры и экспорт в txt") { open(Sub.LOG) }
        }
    }
}

@Composable
fun ConnectScreen(vm: MainViewModel, ui: UiState, scan: () -> Unit, onBack: () -> Unit) {
    val p = LocalPalette.current
    SubHeader("Подключение", onBack)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
        CardBox {
            val status = when (ui.conn) {
                ConnState.READY -> "Подключено · ${ui.connAddress ?: ""}"
                ConnState.CONNECTING -> "Подключение…"
                ConnState.DISCONNECTED -> if (ui.scanning) "Идёт поиск…" else "Не подключено"
            }
            Text(status, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("Закройте оригинальное приложение KCQ Scooter: самокат держит только одно подключение.", color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
            if (ui.conn == ConnState.DISCONNECTED) {
                PrimaryButton(if (ui.scanning) "Поиск…" else "Найти самокат", enabled = !ui.scanning) { scan() }
                val last = ui.lastAddress
                if (last != null) {
                    Spacer(Modifier.height(10.dp))
                    SecondaryButton("Подключиться к последнему") { vm.connectLast() }
                }
            } else {
                SecondaryButton("Отключиться") { vm.disconnect() }
            }
        }
        SectionTitle("Найденные устройства")
        if (ui.found.isEmpty()) {
            Text("Пока пусто. Нажмите «Найти самокат».", color = p.sub, fontSize = 14.sp, modifier = Modifier.padding(start = 6.dp))
        }
        ui.found.forEach { f ->
            Spacer(Modifier.height(8.dp))
            Pressable(onClick = { vm.connect(f.address) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(p.tileRadius), color = p.card) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text((if (f.hasService) "★ " else "") + (f.name ?: "Без имени"), color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text(f.address, color = p.sub, fontSize = 12.sp)
                    }
                    Text("${f.rssi} dBm", color = p.sub, fontSize = 12.sp)
                }
            }
        }
        if (ui.found.isNotEmpty()) {
            Text("★ — устройство с сервисом FFF0 (контроллер KCQ).", color = p.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp, top = 10.dp))
        }
    }
}

@Composable
fun FirmwareScreen(vm: MainViewModel, ui: UiState, askAdvanced: () -> Unit, onBack: () -> Unit) {
    val p = LocalPalette.current
    var pendingProfile by remember { mutableStateOf<SpeedProfile?>(null) }
    SubHeader("Прошивки", onBack)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(p.radius)).background(p.bad.copy(alpha = 0.14f)).padding(16.dp),
        ) {
            Text("⚠️ Опасная операция", color = p.bad, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Прошивка контроллера может окончательно вывести самокат из строя и лишить гарантии. " +
                    "Вся ответственность лежит на разработчике и пользователе, а не на приложении. " +
                    "Приложение предоставляется «как есть», без гарантий.",
                color = p.text, fontSize = 14.sp,
            )
        }
        SectionTitle("Текущая версия")
        CardBox {
            val keys = ui.info.filterKeys { k -> listOf("Firmware", "Hardware", "Software", "Model", "Serial", "System").any { k.contains(it) } }
            if (keys.isEmpty()) {
                Text("Контроллер не сообщает версии прошивки.", color = p.sub, fontSize = 14.sp)
            }
            var first = true
            keys.forEach { (k, v) ->
                if (!first) Divider1()
                first = false
                InfoRow(k, v)
            }
            Spacer(Modifier.height(10.dp))
            SecondaryButton("Прочитать версии", enabled = ui.conn == ConnState.READY) { vm.refreshInfo() }
        }
        SectionTitle("Профили скорости")
        CardBox {
            Text(
                "Прошивка контроллера не нужна: скорости передач меняются штатными командами. " +
                    "Максимум ${Config.MAX_SPEED_KMH} км/ч, дальше контроллер сам ограничивает диапазон. Работает только на стоящем самокате.",
                color = p.sub, fontSize = 14.sp,
            )
            Spacer(Modifier.height(10.dp))
            if (!ui.advanced) {
                Text("Нужно расширенное управление.", color = p.warn, fontSize = 14.sp)
                TextButton(onClick = askAdvanced) { Text("Включить расширенное управление", color = p.accent) }
            }
            SpeedProfiles.all.forEach { prof ->
                Spacer(Modifier.height(8.dp))
                val ready = ui.conn == ConnState.READY && ui.advanced
                val label = "${prof.name}  (${prof.g1} / ${prof.g2} / ${prof.g3})"
                if (prof.max > 25) {
                    PrimaryButton(label, enabled = ready) { pendingProfile = prof }
                } else {
                    SecondaryButton(label, enabled = ready) { vm.applySpeedProfile(prof) }
                }
            }
        }
        SectionTitle("Состояние")
        CardBox {
            Text(if (NoFlasher.available) "Доступно" else "Недоступно", color = if (NoFlasher.available) p.good else p.warn, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(NoFlasher.reason, color = p.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
            PrimaryButton("Прошить", enabled = NoFlasher.available) { vm.say("Прошивка не реализована") }
        }
    }
    val pp = pendingProfile
    if (pp != null) {
        ConfirmDialog(
            title = "Скорость выше 25 км/ч",
            text = "Во многих странах выше 25 км/ч ездить на самокате по общим дорогам нельзя. " +
                "Применить профиль ${pp.name} (${pp.g1} / ${pp.g2} / ${pp.g3} км/ч)?",
            action = "Применить",
            onYes = { vm.applySpeedProfile(pp); pendingProfile = null },
            onNo = { pendingProfile = null },
        )
    }
}

@Composable
fun AboutScreen(onBack: () -> Unit) {
    val p = LocalPalette.current
    SubHeader("О приложении", onBack)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(16.dp))
        Image(painterResource(R.drawable.avatar), contentDescription = null, modifier = Modifier.size(110.dp).clip(CircleShape))
        Spacer(Modifier.height(12.dp))
        Text(Config.APP_NAME, color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Версия ${Config.VERSION}", color = p.sub, fontSize = 14.sp)
        Spacer(Modifier.height(18.dp))
        CardBox {
            InfoRow("Автор", Config.AUTHOR)
            Divider1()
            InfoRow("Самокат", "Ninebot Max G30")
            Divider1()
            InfoRow("Контроллер", "KCQ, BLE FFF0")
        }
        Spacer(Modifier.height(12.dp))
        CardBox {
            Text(
                "Неофициальное приложение. Протокол получен разбором приложения KCQ Scooter 1.5.4. " +
                    "Ninebot, Segway и KCQ — товарные знаки их владельцев. Используйте на свой риск.",
                color = p.sub, fontSize = 13.sp,
            )
        }
    }
}

@Composable
fun LogScreen(vm: MainViewModel, ui: UiState, onBack: () -> Unit) {
    val p = LocalPalette.current
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) vm.export(uri)
    }
    SubHeader("Журнал пакетов", onBack)
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PrimaryButton("Экспорт .txt", Modifier.weight(1f)) { saver.launch("escooter-log.txt") }
        SecondaryButton("Очистить", Modifier.weight(1f)) { vm.clearLog() }
    }
    Spacer(Modifier.height(10.dp))
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        items(ui.log.asReversed()) { line ->
            Text(line, color = p.text, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 2.dp))
        }
    }
}

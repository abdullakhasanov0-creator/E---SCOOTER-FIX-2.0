package com.limonchik.escooter

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Эталонные кадры получены эмуляцией оригинального алгоритма KCQ Scooter 1.5.4
 * (RequestPackage + Utils + SettingInfo/SettingInfo2, строковая логика) для 40960 комбинаций состояний.
 */
class ProtocolTest {

    private fun snap(b11: Int, thirdView: Boolean, pedView: Boolean = false, pedBit2: Boolean = false) =
        Protocol.Snap(Protocol.parseSetting(b11), thirdView, pedView, pedBit2)

    private fun same(expected: ByteArray, actual: ByteArray) = assertArrayEquals(Protocol.hex(expected), expected, actual)

    @Test fun frameChecksum() {
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x08.toByte(), 0x00.toByte(), 0xAD.toByte(), 0x5A.toByte(), 0xEE.toByte()), Protocol.frame(0xA5, 0x08, 0x00))
        for (b1 in 0..255) for (sig in intArrayOf(0xA5, 0xA7, 0xA8)) {
            val f = Protocol.frame(sig, b1, 0x55)
            val x = (b1 xor sig) and 0xFF
            assertEquals(x, f[5].toInt() and 0xFF)
            assertEquals((b1 + sig + x) and 0xFF, f[6].toInt() and 0xFF)
            assertEquals(0xAA.toByte(), f[0]); assertEquals(0xCC.toByte(), f[1]); assertEquals(0xEE.toByte(), f[7])
        }
    }

    @Test fun lights() {
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x08.toByte(), 0x00.toByte(), 0xAD.toByte(), 0x5A.toByte(), 0xEE.toByte()), Protocol.bitCommand(snap(0x01, false), Protocol.W_HEAD, true))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x10.toByte(), 0x00.toByte(), 0xB5.toByte(), 0x6A.toByte(), 0xEE.toByte()), Protocol.bitCommand(snap(0x01, false), Protocol.W_TAIL, true))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x08.toByte(), 0x08.toByte(), 0xAD.toByte(), 0x5A.toByte(), 0xEE.toByte()), Protocol.bitCommand(snap(0x01, true), Protocol.W_HEAD, true))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x09.toByte(), 0x0C.toByte(), 0xAC.toByte(), 0x5A.toByte(), 0xEE.toByte()), Protocol.bitCommand(snap(0x03, true), Protocol.W_HEAD, true))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x08.toByte(), 0x48.toByte(), 0xAD.toByte(), 0x5A.toByte(), 0xEE.toByte()), Protocol.bitCommand(snap(0x01, true, pedView = true, pedBit2 = true), Protocol.W_HEAD, true))
    }

    @Test fun lockAndShutdown() {
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x40.toByte(), 0x00.toByte(), 0xE5.toByte(), 0xCA.toByte(), 0xEE.toByte()), Protocol.bitCommand(snap(0x01, false), Protocol.W_LOCK, true))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x80.toByte(), 0x00.toByte(), 0x25.toByte(), 0x4A.toByte(), 0xEE.toByte()), Protocol.shutdown(snap(0x01, false)))
    }

    @Test fun gears() {
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x01.toByte(), 0x0C.toByte(), 0xA4.toByte(), 0x4A.toByte(), 0xEE.toByte()), Protocol.gear3(snap(0x01, true)))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x01.toByte(), 0x08.toByte(), 0xA4.toByte(), 0x4A.toByte(), 0xEE.toByte()), Protocol.gear2(snap(0x01, true)))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x00.toByte(), 0x08.toByte(), 0xA5.toByte(), 0x4A.toByte(), 0xEE.toByte()), Protocol.gear1(snap(0x02, true)))
    }

    @Test fun pedestrianAndRestore() {
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x00.toByte(), 0x60.toByte(), 0xA5.toByte(), 0x4A.toByte(), 0xEE.toByte()), Protocol.pedestrian(snap(0x01, true, pedView = true), true))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x00.toByte(), 0x00.toByte(), 0xA5.toByte(), 0x4A.toByte(), 0xEE.toByte()), Protocol.pedestrian(snap(0x01, false), false))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA5.toByte(), 0x01.toByte(), 0x0D.toByte(), 0xA4.toByte(), 0x4A.toByte(), 0xEE.toByte()), Protocol.restore(snap(0x03, true)))
    }

    @Test fun speedFrames() {
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA7.toByte(), 0x0F.toByte(), 0x19.toByte(), 0xA8.toByte(), 0x5E.toByte(), 0xEE.toByte()), Protocol.speed12(15, 25))
        same(byteArrayOf(0xAA.toByte(), 0xCC.toByte(), 0xA8.toByte(), 0x1E.toByte(), 0x08.toByte(), 0xB6.toByte(), 0x7C.toByte(), 0xEE.toByte()), Protocol.speed3(30, 0, 20))
    }

    @Test fun parseSettingBits() {
        val s = Protocol.parseSetting(0b1011_0101)
        assertEquals(1, s.gear)
        assertTrue(s.cruise); assertTrue(!s.startMode); assertTrue(s.headlight); assertTrue(s.taillight)
        assertTrue(!s.unitMiles); assertTrue(s.lock)
        assertEquals(3, Protocol.parseSetting(0x03).gear)
        assertEquals(2, Protocol.parseSetting(0x02).gear)
    }

    @Test fun parseStatusLayout() {
        val f = byteArrayOf(
            0xAA.toByte(), 0x55, 0x2C, 0x01, 0x10, 0x00, 0x05, 0x00, 0x57, 0x01, 0x20, 0x13, 0x3C, 0x00,
        )
        val st = Protocol.parseStatus(f)!!
        assertEquals(300, st.speedRaw)
        assertEquals(30.0, st.speedKmh, 0.0001)
        assertEquals(16, st.totalRaw)
        assertEquals(5, st.tripRaw)
        assertEquals(87, st.battery)
        assertEquals(1, st.faults.size)
        assertTrue(st.thirdGearView)
        assertEquals(60, st.rideSeconds)
        assertNull(Protocol.parseStatus(byteArrayOf(0x00, 0x01)))
    }

    @Test fun parsePedAndBounds() {
        val p = Protocol.parsePed(byteArrayOf(0xAA.toByte(), 0x56, 0x05, 0, 0, 15, 25, 30, 8))!!
        assertTrue(p.view); assertTrue(!p.bit1); assertTrue(p.bit2)
        assertEquals(15, p.one); assertEquals(25, p.two); assertEquals(30, p.three); assertEquals(8, p.start)
        val b = Protocol.parseBounds(byteArrayOf(0xAA.toByte(), 0x57, 0, 0, 0, 0, 0, 0, 5, 20, 10, 30, 15, 50))!!
        assertEquals(5 to 20, b.range(1)); assertEquals(10 to 30, b.range(2)); assertEquals(15 to 50, b.range(3))
    }

    @Test fun speedProfileFrames() {
        // профиль «до 50»: A7 = 25/35, A8 = 50 и стартовая 8 (при стартовой 0 и 3-я >= текущей)
        same(Protocol.frame(0xA7, 25, 35), Protocol.speed12(25, 35))
        same(Protocol.frame(0xA8, 50, 8), Protocol.speed3(50, 0, 30))
        assertEquals(50, SpeedProfiles.MAX50.max)
        assertTrue(SpeedProfiles.all.all { it.max <= Config.MAX_SPEED_KMH })
    }
}
